
class CLI_Audio_File_Exception(Exception):
    pass

class CLI_Audio_Screen_Size_Exception(Exception):
    pass




